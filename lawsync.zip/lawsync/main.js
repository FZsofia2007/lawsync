const passwordInput = document.getElementById("password");
const toggleIcon = document.querySelector(".toggle-password");

toggleIcon.addEventListener("mouseenter", () => {
  passwordInput.type = "text";
  toggleIcon.classList.remove("bi-eye");
  toggleIcon.classList.add("bi-eye-slash");
});

toggleIcon.addEventListener("mouseleave", () => {
  passwordInput.type = "password";
  toggleIcon.classList.remove("bi-eye-slash");
  toggleIcon.classList.add("bi-eye");
});
